#ifndef DCN_H
#define DCN_H
/******************************** Inclusions. *************/
SEXP dcn (SEXP rygeomd, SEXP rx, SEXP ry, SEXP rcount, SEXP rcentroidxd, SEXP rcentroidyd, SEXP rl1, SEXP rl2, SEXP rl3, SEXP rdup, SEXP rlast, SEXP rparamint, SEXP rparamdouble, SEXP roptions);
#endif
