#ifndef CHECKRING_H
#define CHECKRING_H
/******************************** Inclusions. *************/
SEXP checkring (SEXP rygeom, SEXP rmultipoly, SEXP roptions) ;
#endif
