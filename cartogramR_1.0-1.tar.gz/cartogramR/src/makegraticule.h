#ifndef __MAKEGRATICULE_H_
#define __MAKEGRATICULE_H_
/******************************** Inclusions. *************/
SEXP makeoriggraticule (SEXP rpadding, SEXP rLL, SEXP rbbox) ;
SEXP makefinalgraticule (SEXP rpadding, SEXP rLL, SEXP rbbox, SEXP rgridx, SEXP rgridy) ;
#endif
