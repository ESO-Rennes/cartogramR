#ifndef CARACMAP_H
#define CARACMAP_H
/********************************** Macros. **********************************/
/**************************** Function prototypes. ***************************/
void caract_map (double *caracmapd, int *caracmapi, double padding,
		  int LL, double map_maxx, double map_maxy,
		 double map_minx, double map_miny) ;
#endif
