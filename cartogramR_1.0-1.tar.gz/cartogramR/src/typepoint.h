#ifndef __TYPEPOINT_H_
#define __TYPEPOINT_H_
/*********************************** Types. **********************************/
typedef struct {      /* Useful structure for coordinates in two dimensions. */
  double x;
  double y;
} POINT;
#endif // __TYPEPOINT_H_
